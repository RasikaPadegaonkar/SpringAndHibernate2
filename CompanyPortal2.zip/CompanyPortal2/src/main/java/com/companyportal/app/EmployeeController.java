package com.companyportal.app;


import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.companyportal.app.entity.Employee;
import com.companyportal.app.service.EmployeeService;

@Controller
public class EmployeeController {

	@Autowired
	private EmployeeService employeeService;
	
	private static int currentEmpId;

	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String displayRegistrationForm(Model model) {
		Employee employee = new Employee();	
		
		model.addAttribute("employee", employee);
		return "employeeform";
		
		//return new ModelAndView("employeeform", "employee", employee);
		 
	}
	
	@RequestMapping(value = "/saveData", method = RequestMethod.POST)
	public String saveEmployeeData(@ModelAttribute Employee employee) {
		employeeService.saveEmployeeData(employee);
		
		return "redirect:/employeelist";
	}
	
	@RequestMapping(value = "/employeelist", method = RequestMethod.GET)
	public String getEmployeesData(Model model) {
		List<Employee> employeeList = employeeService.getEmployeesData();
				
		model.addAttribute("employeeList", employeeList);
		return "employeelist";
	}
	
	// It updates employee    
    @RequestMapping(value="/updateEmployeeData",method = RequestMethod.GET)    
    public String updateEmployee(@ModelAttribute Employee employee){   
        employeeService.updateEmployee(employee,currentEmpId);    
        return "redirect:/employeelist";    
    }    
    
    @RequestMapping(value = "/updateEmployee", method = RequestMethod.GET)
	public String displayUpdatedForm(@RequestParam("employeeId") int employeeId) {
    	System.out.println("updating-------");
		currentEmpId= employeeId;
		return "updatedform";
		
		//return new ModelAndView("employeeform", "employee", employee);
		 
	}
    
    
	//delete employee
	@RequestMapping(value = "/deleteEmployee/{employeeId}", method = RequestMethod.GET)
	public String deleteEmployeesData(@PathVariable int employeeId) {
		 employeeService.deleteEmployee(employeeId);
		 return "redirect:/employeelist";
				
	}
	
	//search employee
	@RequestMapping(value = "/searchByEmployeeName", method = RequestMethod.POST)
	public ModelAndView searchEmployeesByName(@RequestParam("Name")String employeeName) {
		ModelAndView mv=new ModelAndView();
		mv.setViewName("employeelist");
		System.out.println("search in employeelist" +employeeName);
		mv.addObject("employeeList",employeeService.searchEmployeeByName(employeeName));
		return mv;
	}
	
	
	
}
